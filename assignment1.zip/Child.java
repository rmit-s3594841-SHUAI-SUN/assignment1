
    import java.util.ArrayList;
	/**
	 * This class's author is Xuesong Zeng s3588486
	 */
    public class Child extends Person {
    	public ArrayList<Child> friend = new ArrayList<Child>();
    	public ArrayList<Adult> parents = new ArrayList<Adult>(2);
    	
    	
    	public Child(){}
		/**
		 *class constructor
		 */
    	public Child( String name, String gender, double age, String status) {
    	        super(name, gender, age, status);
    	    }

		/**
		 *This method makes a child add another child as a friend. and the other child will also treat this child
		 * as a friend.
		 * @param child here represents the child whom this child wants to add as a friend.
		 */
    	public void setFriend(Child child) {
    		this.friend.add(child);
    		
    		child.friend.add(this);

    	}

		/**
		 *This method can select a friend for children
		 * @param child here represents the child whom this child wants to add as a friend.
		 * @return true or false.
		 */
    	public boolean selectFriend(Child child) {
    		if(this.friend.contains(child)) {
    			return true; 
    		}else {
    			return false;
    		}
    	}

    	

    }




