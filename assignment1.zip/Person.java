
/**
 * This class's author is Xuesong Zeng s3588486
 */
public abstract class Person {
    private String name;
    private String gender;
    private double age;
    private String status;


    public Person () {}

    /**
     *class constructor
     */

    public Person(String name, String gender, double age, String status) {
     
        this.name = name;
        this.gender = gender;
        this.age = age;
        this.status = status;
    }
    
    public String getName() {
        return name;
    }
    public String getGender(){
        return gender;
    }
    public double getAge(){
        return age;
    }
    public String getStatus(){
        return status;
    }

    public void setName(String name){
        this.name = name;
    }
    public void setGender(String gender){
        this.gender = gender;
    }
    public void setAge(double age){
        this.age = age;
    }
    public void setStatus(String status){
        this.status = status;
    }
    
}

