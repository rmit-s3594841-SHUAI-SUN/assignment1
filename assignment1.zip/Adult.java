

import java.util.ArrayList;
/**
 * This class's author is Xuesong Zeng s3588486
 */
public class Adult extends Person {
	public ArrayList<Adult> friend = new ArrayList<Adult>();
	public ArrayList<Adult> couple = new ArrayList<Adult>(1);
	public ArrayList<Child> children = new ArrayList<Child>();

	public Adult(){}
	/**
	 *class constructor
	 */
    public Adult(String name, String gender, double age, String status) {
        super( name, gender, age, status);
    }
	

	
	public void setFriend(Adult adult) {
		this.friend.add(adult);
		adult.friend.add(this);
	}

	public void setCouple (Adult adult) {
		this.couple.add(adult);
		adult.couple.add(this);
		}

	/**
	 * This function is to add a child for adult
	 * @param child here represents the child whom this child wants to add as a child
	 */
	public void setChild(Child child) {
			this.children.add(child);
			if( this.getName() != this.couple.get(0).getName()) {
				this.couple.get(0).children.add(child);
				child.parents.add(this);
				child.parents.add(this.couple.get(0));
			}else 
				{
					this.couple.get(1).children.add(child);
					child.parents.add(this);
					child.parents.add(this.couple.get(1));
				}
			
	}

	/**
	 * To identify the relationship between persons
	 * @param adult here represents the other adult who is tested
	 * @return true or false ,if they are friends, it will return true. if they are not friends ,return false
	 */
	public boolean selectFriend(Adult adult) {
		if(this.friend.contains(adult)) {
			return true;
		}else {
			return false;
		}
	}
	public boolean selectCouple(Adult adult) {
		if(this.couple.contains(adult)) {
			return true;
		}else {
			return false;
		}
	}
	public boolean selectChild(Child child) {
		if(this.children.contains(child)) {
			return true;
		}else {
			return false;
		}
	}

	
}
	


