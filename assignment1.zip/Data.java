import java.util.ArrayList;
/**
 * This class's author is Xuesong Zeng s3588486
 */
public class Data {

	public ArrayList<Person> pr = new ArrayList<Person>();

}