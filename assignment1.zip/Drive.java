import java.util.ArrayList;
import java.util.Scanner;

/**
 * This class's author is Shuai Sun s3594841
 */
public class Drive {
    private String option;
    Scanner sc = new Scanner(System.in);
    Data a = new Data();

    /**
     * This method provide different selection for user
     */
    private void menu() {
    	
    	preparedData(a.pr);
        while(true) {
            System.out.println("MiniNet Menu");
            System.out.println("===================================");
            System.out.println("1.List everyone");
            System.out.println("2.Select a person");
            System.out.println("3.Add a person");
            System.out.println("4.Identify the relation between two persons");
            System.out.println("5.Exit");
            System.out.println("Please enter an option");

            option = sc.nextLine();
            switch (option) {
                case "1":
                    display(a.pr);
                    break;

                case "2":
                	System.out.println();
                    subMenu(a.pr, selectPerson(a.pr));
                    break;

                case "3":
                	addPerson(a.pr);
                    break;

                case "4":
                	displayConnection(a.pr);
                    break;
                case "5":
                	System.exit(0);

                default:
                    System.out.println("invalid input : please enter a valid option.");
                    break;
            }
            System.out.println();
        }

    }
    

    /**
     * It is useful for java encapsulation
	 * It is a set of prepared data for testing functions of this program.
     * @param pr	pr is the arraylist that stores the data. The elements in the arraylist is objects of Person.
     */

    private void preparedData(ArrayList<Person> pr) {
    	
    	Adult adult0 = new Adult("AA", "M", 22.5, "I am happy");
    	Adult adult1 = new Adult("BB", "F", 25.5, "Today, I have a lot of things to do");
    	Adult adult2 = new Adult("CC", "M", 34, "So tired");
    	Adult adult3 = new Adult("DD", "F", 40, "I will join a party tonight");
    	Child child0 = new Child("aa", "M", 7, "Hahahaha, I do not have homework");
    	Child child1 = new Child("bb", "M", 8, "Oh, The weather is terrible");
    	Child child2 = new Child("cc", "M", 13, "I do not want to go to school");
    	Child child3 = new Child("dd", "M", 2, "Everything is new");
    	pr.add(adult0);
    	pr.add(adult1);
    	pr.add(adult2);
    	pr.add(adult3);
    	pr.add(child0);
    	pr.add(child1);
    	pr.add(child2);
    	pr.add(child3);
    	
    	adult0.setFriend(adult2);
    	adult0.setFriend(adult3);
    	
    	adult0.setCouple(adult1);
    	adult0.setChild(child0);
    	adult0.setChild(child1);
    	adult0.setChild(child2);
    	adult0.setChild(child3);
 
    	child1.setFriend(child2);
    }
	/**
	 * subMenu is a method that providing a sub-menu when choose select someone in menu.
	 * This method provides 5 options including delete a person, modify the profile, add a friend or other relaitonship,
	 * and show all relationships of this selected person from the arraylist pr.
	 * @param pr is the arraylist stored in class Data.
	 * @param person 	person here is the object selected by method "selectPerson", then the program knows
	 *                  which object is required operation.
	 * @return
	 */
    private void subMenu(ArrayList<Person> pr, Person person){
    	if( pr.contains(person)) {
    		System.out.println("1.Delete this person");
            System.out.println("2.modify the profile of a person");
            System.out.println("3.Add a friend for this person");
            System.out.println("4.Add a couple for this person");
            System.out.println("5.Show all connections of this person");
            option = sc.nextLine();
            switch (option) {
                case "1":
                    deletePerson(pr, person);
                    break;
                case "2":
                    modifyProfile(person);
                    break;
                case "3":
                	connectFriend(pr, person);
                	break;
                case "4":
                	connectCouple(pr, person);
                	break;
                case "5":
                	showConnection(person);
                	break;
                    default:
                        System.out.println("Invalid input : please enter a valid option.");
                        subMenu( pr, person);
            }
        	}
      }


	/**
	 * @param  pr is the arraylist that stores the data. The elements in the arraylist is objects of Person
	 * This method is to display all people existing in the Net.
	 * @return does not have return value.
	 */
    
	private void display(ArrayList<Person> pr){
    	if( !pr.isEmpty() ) {
    		for(int i = 0; i< pr.size(); i++){
    			System.out.println(pr.get(i).getName()+" " + pr.get(i).getAge() + " "+ pr.get(i).getGender()+ " "+pr.get(i).getStatus()  );
    		}
    	}else System.out.println("There is nobody in this Net, please add at least one first.");

    }
	/**
	 * This method is to select one person in the net and then to delete or modify this person.
	 * It selects person by name, this method will ask the user to enter the name and then to check whether existing
	 * an Person object has the matched name.
	 * @param pr	pr is the arraylist that store that who is added into the net.
	 *
	 * @return	this method will return a reference that points to the object in the arraylist, so that we can use this
	 * reference to  update the data of this Person object.
	 */
    private Person selectPerson(ArrayList<Person> pr){
    	//boolean flag = false;
    	if( !pr.isEmpty()) {
	    		int i;
		        System.out.println("enter a name to select.");
		        String name;
		        name = sc.nextLine();
		        for( i = 0; i < pr.size(); i++){
		            if(name.equals(pr.get(i).getName())){
		            	//flag = true;
		                System.out.println(pr.get(i).getName()+ " is selected.");
		                System.out.println();
		                return pr.get(i);
		            }
		        }
		        System.out.println("Cannot find this person.");
		        System.out.println();
    		}       
    	else {
    		System.out.println("There is nobody to select, please add at least one first.");
    		System.out.println();
    	}
    	return null;
    }

	/**
	 * This method is to add one person in the net work
	 * @param  pr is the arraylist that stores the data. The elements in the arraylist is objects of Person
	 */

	private void addPerson(ArrayList<Person> pr) {
    	String name;
    	double age = 0;
    	String gender;
    	String status;
    	boolean flag = false;
        System.out.println("Please input the name of the new person:");
        name = sc.nextLine();
        for( int i = 0; i < pr.size(); i++) {
        	if( pr.get(i).getName().matches(name)) {
        		System.out.println(name + " has been in the net.");
        		flag = true;
        	}
        }
        if( !flag ){
        	while (!flag) {
		        System.out.println("Please input the age of the new person:");
		        try {
		        	age = sc.nextDouble();
		        	sc.nextLine();
		        	flag = true;
		        }
		        catch(Exception e) {
		        	System.out.println("Please enter the age, which should be a number.");
		        	sc.nextLine();
		        }
        	}
        	flag = false;
	        System.out.println("What is the gender? Please enter M or F");
	        gender = sc.nextLine();
	        while( !gender.matches("M")  && !gender.matches("F") ) {
	        	System.out.println("Your input is invalid. Please try again.");
	        	System.out.println("What is the gender? Please enter M or F");
	        	gender = sc.nextLine();
	        }
	        System.out.println("Please edit the status of this person.");
	        status = sc.nextLine();
	        
	        if ( age <= 16) {
	        	addChild(pr, name, age, gender, status);
	        }else{	
	        	addAdult(pr, name, age, gender, status);
	        }
        }
    }

	/**
	 * This method provide many different constrains to make sure user add a child rather than a adult
	 * @param pr is the arraylist that stores the data. The elements in the arraylist is objects of Person
	 * @param name 	the content of name has been read into the program in the method addPerson. then the name need
	 *              sending to the method addChild to create a new object of Child.
	 * @param age  is same as name.
	 * @param gender is same as name.
	 * @param status is same as name
	 */
    
    private void addChild(ArrayList<Person> pr, String name, double age, String gender, String status) {
    	Child child = new Child();
    	System.out.println("Please enter the name of one of parents of this child.");
    	Person person = selectPerson(pr);
    	if (person instanceof Adult) {
    		Adult adult = (Adult) person;
    		if( adult.couple.isEmpty()) {
    			System.out.println(adult.getName() + "is single, cannot be a parent.");
    		}else if ((adult.getAge() - child.getAge() < 16) || (adult.couple.get(0).getAge() - child.getAge() < 16)){
    			System.out.println( "Parents should be at least 16 years old elder than their children." );
    		}else{
    			adult.setChild(child);
    			child.setName(name);
    			child.setAge(age);
    			child.setGender(gender);
    			child.setStatus(status);
    			pr.add(child);
    			System.out.println(name + " now is in the net.");
    		}
    	}else {
    		System.out.println(person.getName() + " is still a child, cannot be a parent.");
    	}
    }

	/**
	 * This method is similar as addChild. this method is to add an adult into the arraylist, as well as the net.
	 * @param pr is the arraylist that stores the data. The elements in the arraylist is objects of Person
	 * @param name 	the content of name has been read into the program in the method addPerson. then the name need
	 *              sending to the method addAdult to create a new object of Adult.
	 * @param age  is same as name.
	 * @param gender is same as name.
	 * @param status is same as name
	 */

    private void addAdult(ArrayList<Person> pr, String name, double age, String gender, String status) {
    	Adult adult = new Adult();
    	adult.setName(name);
    	adult.setAge(age);
    	adult.setGender(gender);
    	adult.setStatus(status);
    	pr.add(adult);
    	System.out.println(name + " now is added into the net.");
    }

	/**
	 * This method makes the program has the function that update the profile of a selected person.

	 * @param person represents the object that the user choosed in the method selectPerson.
	 */
    private void modifyProfile( Person person ){
    	System.out.println("please, modify the profile");
        System.out.println("enter 1 to change name");
        System.out.println("enter 2 to change age");
        System.out.println("enter 3 to change gender");
        System.out.println("enter 4 to change status");
        option =sc.nextLine();
        switch(option) {
        case "1":
        	System.out.println("enter the new name");
        	String name;
        	name = sc.nextLine();
        	person.setName(name);
            break;
        case "2":
        	System.out.println("enter the new age");
            person.setAge(sc.nextInt());
            break;
        case "3":
        	System.out.println("enter the new gender");
            person.setGender(sc.nextLine());
            break;
        	
        case "4":
        	System.out.println("enter the new status");
            person.setStatus(sc.nextLine());
            break;
        	default:
        		 System.out.println("invalid input : please enter a valid option.");
        		 modifyProfile( person );
        }
        System.out.println();

    }

	/**
	 * This method makes the program has the function that remove a selected person from the net. In addition, this
	 * method will update the relation arraylist after removing a person from the net. For example, if the user delete
	 * a parent who has friends, couple, and children in this net, friends of the deleted person would no longer have
	 * the relationship of friend with this person; the couple of this person would become single and their children
	 * would no longer exist in the net, as if this person has never existed in this net. Besides, the relationship of
	 * the deleted person's children would also update. what mentioned above is to guarantee that children in the net
	 * must have two parents, and someone that is single cannot be a parent of children.
	 * @param pr is the arraylist that stores the data. The elements in the arraylist is objects of Person.
	 *           It makes sure that different methods in this program operate a same arraylist.
	 * @param person represents the object that the user choosed in the method selectPerson.
	 */
    private void deletePerson(ArrayList<Person> pr, Person person){
    	pr.remove(person);
    	if ( person instanceof Adult) {
    		Adult adult = (Adult) person;
    		for ( int i = 0; i < adult.friend.size(); i++) {
    			adult.friend.get(i).friend.remove(adult);
    		}
    		if ( !adult.couple.isEmpty()) {
    			if( !adult.children.isEmpty()) {
    				for (int i = 0; i < adult.children.size(); i++) {
    					pr.remove(adult.children.get(i));
    					if(!adult.children.get(i).friend.isEmpty()) {
    						for( int j = 0; j < adult.children.get(i).friend.size(); j++) {
    							adult.children.get(i).friend.get(j).friend.remove(adult.children.get(i));

    						}
    					}
    				}
    			}
    			adult.couple.get(0).children.clear();
    			adult.couple.get(0).couple.clear();
				System.out.println(adult.getName() + " has been deleted.");
    		}
    	}else {
    		Child child = (Child) person;
    		pr.remove(child);
    		if( !child.friend.isEmpty()) {
    			for( int i = 0; i < child.friend.size(); i++) {
    				child.friend.get(i).friend.remove(child);
    			}
    		}
    		child.parents.get(0).children.remove(child);
    		child.parents.get(1).children.remove(child);
			System.out.println(child.getName() + " has been deleted.");
    	}
    }
	/**
	 * This method can make two people become friends or couples. however, there are some constrains, like an adult can
	 * only make friends with adulds, children can only make friends with children from other familis.
	 * @param pr is the arraylist that stores the data. The elements in the arraylist is objects of Person.
	 *           It makes sure that different methods in this program operate a same arraylist.
	 * @param person represents the object that the user choosed in the method selectPerson.
	 */
    private void connectFriend(ArrayList<Person> pr,  Person person) {
    	
    	System.out.println("Now the Network contains:");
    	display(pr);
    	System.out.println("Please enter the name of whom you want to add for this person");
    	Person person1 = selectPerson(pr);
    	if (person instanceof Adult && person1 instanceof Adult) {
	    	try {
	    	    	Adult adult1 = (Adult) person;
	    	    	Adult adult2 = (Adult) person1;
		    		if( adult1.selectFriend(adult2)  == false) {
		    			adult1.setFriend(adult2);	    			
	
		    		}else {
		    			System.out.println("They have been friends already");
		    	}
	    	}catch(Exception e){
	    		System.out.println("Invaild input! "+e.getMessage());
	    	}
    	}else if(person instanceof Child && person1 instanceof Child) {
    		try {
    			Child child1 = (Child) person;
    			Child child2 = (Child) person1;
    		    if(child1.selectFriend(child2) == true) {
    		    	System.out.println("They are already friends");
    		    }else if (child1.parents.get(0).children.contains(child2)) {
    		    	System.out.println(child1.getName() + " and " + child2.getName() + " are brothers or sisters, sharing same parents.");
    		    	System.out.println("Children can only add children from different family as friends.");
    		    }
    		    else if(person.getAge() > 2 && person1.getAge() > 2 && 
    		    		((child1.getAge() - child2.getAge()) <= 3 || (child2.getAge() - child1.getAge()) <= 3  )) {
    		    	child1.setFriend(child2);
    		    }else if( (child1.getAge() - child2.getAge()) > 3 || (child2.getAge() - child1.getAge()) > 3  ) {
    		    	System.out.println("They cannot be friends because the age gap between them is over 3 years old.");
				}
    	    	}catch(Exception e) {
    	    		System.out.println("Invaild input! "+e.getMessage() );
    	    	}
    	}else System.out.println("An adult can only be friend of adults, a children can only be friend of children.");
    }

	/**
	 * This method can make two people become couples.There are also some constrains.
	 * @param pr is the arraylist that stores the data. The elements in the arraylist is objects of Person.
	 *           It makes sure that different methods in this program operate a same arraylist.
	 * @param person represents the object that the user choosed in the method selectPerson.
	 */
    
    private void connectCouple(ArrayList<Person> pr,  Person person) {
        if( person instanceof Adult) {
	    	
	        System.out.println("Now the Network contains:");
	        display(pr);
	        System.out.println("Please enter the name of whom you want to add for this person");
	        Person person1 = selectPerson(pr);
	        if (person1 instanceof Adult) {
	        	Adult adult1 = (Adult) person;
		        Adult adult2 = (Adult) person1;
		        if( adult1.couple.isEmpty() && adult2.couple.isEmpty()) {
		           	adult1.setCouple(adult2);        
		           }else {
		            System.out.println("At least one of these two is not single.");
		          }
	         }else System.out.println("Only two adults can be couples.");
         } else System.out.println("Invalid input: this person is not an adult.");    
    }

	/**
	 *This method can display the Connection between different person
	 * @param pr is the arraylist that stores the data. The elements in the arraylist is objects of Person.
	 *           It makes sure that different methods in this program operate a same arraylist.
	 */

	private void displayConnection(ArrayList<Person> pr) {
    	System.out.println("The 1st person");
    	Person person = selectPerson(pr);
    	System.out.println("The 2nd person");
    	Person person1 = selectPerson(pr);
    	if(person instanceof Adult && person1 instanceof Adult) {
	    	Adult adult = (Adult) person;
	    	Adult adult1 = (Adult) person1;
	    	if( adult.selectFriend(adult1)) {
	    		System.out.println("they are friends");
	    	}else if ( adult.selectCouple(adult1)) {
	    		System.out.println("They are couples");
	    	}
	    	else System.out.println("They have no connection.");
    	}else if ( person instanceof Child && person1 instanceof Child ) {
    		Child child = (Child) person;
    		Child child1 = (Child) person1;
    		if( child.selectFriend(child1)) {
    			System.out.println("They are friend.");
    		}else if ( child.parents.get(0).children.contains(child1)) {
    			System.out.println("They share sanme parents. They are brothers or sisters. ");
    		}else System.out.println("They have no connection.");
    	}else if ( (person instanceof Adult && person1 instanceof Child) || (person instanceof Person && person1 instanceof Child)) {
    		if( person.getAge() > person1.getAge()) {
    			Adult adult = ( Adult) person;
    			Child child = (Child) person1;
    			if( adult.selectChild(child)) System.out.println(child.getName() + " is " + adult.getName() + "'s child.");
    		}else {	
    			Child child = (Child) person;
    			Adult adult = ( Adult) person1;
    			if( adult.selectChild(child)) System.out.println(child.getName() + " is " + adult.getName() + "'s child.");
    		}
    	}else System.out.println("They have no connection.");
    }

	/**
	 * This method is to show the Connection between different person such as parents, couples, friends.
	 * There are also some constrains which use to identify
	 * different connections
	 * @param person represents the object that the user choosed in the method selectPerson.
	 */
	private void showConnection(Person person) {
    	if( person instanceof Adult) {
    	System.out.print(person.getName()+ "'s friends contain: ");
    	Adult adult = (Adult) person;
        for (int j = 0; j < adult.friend.size(); j++) {
        	System.out.print(adult.friend.get(j).getName() + " ");
        }//show an adult's friends
        System.out.println();
        if( !adult.couple.isEmpty()) {
        	System.out.print(adult.getName()+"'s couple is "+adult.couple.get(0).getName());
        }
        
        System.out.println();
        System.out.print(adult.getName()+"'s children contain: ");
        for (int j = 0; j < adult.children.size(); j++) {
        	System.out.print(adult.children.get(j).getName()+ " ");
        }
        System.out.println();
    	}else if(person instanceof Child) {
    		System.out.print(person.getName()+ "'s friends contain: ");
        	Child child = (Child) person;
            for (int j = 0; j < child.friend.size(); j++) {
            	System.out.print(child.friend.get(j).getName() + " ");
            }//show an adult's friends
            
            System.out.println();
            System.out.print(child.getName()+"'s parents are  ");
            
            System.out.print(child.parents.get(0).getName()+ " and " + child.parents.get(1).getName() + ".");
            
            System.out.println();
    	}
    }
      
    public void runDrive(){
        this.menu();
    }
}
