
public class MiniNet {
	/**
	 * This class's author is Xuesong Zeng s3588486
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Drive drive = new Drive();
		drive.runDrive();
	}

}
